# Vagrant - or - how to code in your local computer

## Learning Objectives

 At the end of this project, you are expected to be able to explain to anyone, without the help of Google:

* What is a virtual machine

* What is Vagrant

* Who wrote Vagrant

* What is Ubuntu
